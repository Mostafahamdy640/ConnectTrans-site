import React, { useState } from 'react';
import { X, CheckCircle2, Truck, Calendar, MapPin, DollarSign, ArrowLeft } from 'lucide-react';
import { CITIES, TRUCK_TYPES } from '../data/mockData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDetails?: {
    fromCity?: string;
    toCity?: string;
    truckType?: string;
    weight?: number;
    price?: number;
  };
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialDetails,
}) => {
  const [fromCity, setFromCity] = useState(initialDetails?.fromCity || 'الرياض');
  const [toCity, setToCity] = useState(initialDetails?.toCity || 'جدة');
  const [truckType, setTruckType] = useState(initialDetails?.truckType || 'flatbed');
  const [cargoName, setCargoName] = useState('');
  const [pickupDate, setPickupDate] = useState('اليوم أو خلال 24 ساعة');
  const [phone, setPhone] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [trackingNumber, setTrackingNumber] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedCode = `CT-${Math.floor(10000 + Math.random() * 90000)}`;
    setTrackingNumber(generatedCode);
    setConfirmed(true);
  };

  const resetAndClose = () => {
    setConfirmed(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black">طلب شاحنة ونقل شحنة جديدة</h3>
              <p className="text-xs text-slate-300">ربط مباشر مع أقرب سائق شاحنة متاح لمسارك</p>
            </div>
          </div>
          <button
            onClick={resetAndClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {confirmed ? (
            <div className="py-8 text-center space-y-4">
              <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto animate-bounce" />
              <h4 className="text-2xl font-black text-slate-900">تم إرسال طلب الشحن بنجاح!</h4>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                تم تعميم طلبك على الشاحنات المتواجدة في مدينة <span className="font-bold text-slate-900">{fromCity}</span>. ستتلقى عروض الأسعار والتأكيد عبر رسالة نصية قصيرة على رقمك.
              </p>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl max-w-xs mx-auto">
                <span className="text-xs text-slate-500 block mb-1">رمز التتبع المبدئي:</span>
                <span className="text-xl font-mono font-black text-blue-700">{trackingNumber}</span>
              </div>

              <div className="pt-4">
                <button
                  onClick={resetAndClose}
                  className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl cursor-pointer"
                >
                  العودة للرئيسية
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">مدينة التحميل:</label>
                  <select
                    value={fromCity}
                    onChange={(e) => setFromCity(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  >
                    {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">مدينة التوصيل:</label>
                  <select
                    value={toCity}
                    onChange={(e) => setToCity(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  >
                    {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">نوع الشاحنة المطلوبة:</label>
                  <select
                    value={truckType}
                    onChange={(e) => setTruckType(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  >
                    {TRUCK_TYPES.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">نوع البضاعة وحالتها:</label>
                  <input
                    type="text"
                    required
                    value={cargoName}
                    onChange={(e) => setCargoName(e.target.value)}
                    placeholder="مثال: أجهزة كهربائية، مواد غذائية"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">موعد التحميل المقترح:</label>
                  <select
                    value={pickupDate}
                    onChange={(e) => setPickupDate(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  >
                    <option value="اليوم أو خلال 24 ساعة">اليوم أو خلال 24 ساعة (عاجل)</option>
                    <option value="خلال يومين إلى 3 أيام">خلال يومين إلى 3 أيام</option>
                    <option value="نهاية الأسبوع">نهاية الأسبوع الحالي</option>
                    <option value="شحنة مجدولة شهرياً">شحنة مجدولة أسبوعياً/شهرياً</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">رقم جوال المسؤول للتنسيق:</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="05xxxxxxxx"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
              </div>

              {initialDetails?.price && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs font-bold text-amber-900">
                  <span>السعر المقدر المحسوب:</span>
                  <span className="text-base text-blue-700">{initialDetails.price.toLocaleString()} ريال</span>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-sm rounded-xl transition-all shadow-md cursor-pointer"
                >
                  تأكيد إرسال طلب الشحن
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
