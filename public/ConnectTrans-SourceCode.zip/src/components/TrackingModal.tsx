import React, { useState } from 'react';
import { X, Search, MapPin, Truck, CheckCircle2, Clock, Navigation, AlertCircle } from 'lucide-react';
import { SAMPLE_SHIPMENTS } from '../data/mockData';
import { Shipment } from '../types';

interface TrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTrackingCode?: string;
}

export const TrackingModal: React.FC<TrackingModalProps> = ({ isOpen, onClose, initialTrackingCode = 'CT-89214' }) => {
  const [searchQuery, setSearchQuery] = useState(initialTrackingCode);
  const [currentShipment, setCurrentShipment] = useState<Shipment | null>(SAMPLE_SHIPMENTS[0]);
  const [notFound, setNotFound] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim().toUpperCase();
    const found = SAMPLE_SHIPMENTS.find(s => s.trackingNumber.toUpperCase() === query);
    if (found) {
      setCurrentShipment(found);
      setNotFound(false);
    } else {
      // Create dynamic preview for any tracking ID entered
      if (query.length > 3) {
        setCurrentShipment({
          id: 'custom',
          trackingNumber: query,
          sender: 'شحنة تجارية معتمدة',
          fromCity: 'الرياض',
          toCity: 'جدة',
          truckType: 'تريلا مقفلة',
          cargoType: 'بضائع عامة مجدولة',
          weightTons: 18,
          price: 3100,
          status: 'in_transit',
          currentLocation: 'طريق الرياض - مكة السريع (الكيلو 420)',
          progressPercent: 65,
          estimatedArrival: 'غداً، 08:00 صباحاً'
        });
        setNotFound(false);
      } else {
        setNotFound(true);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-blue-400">
              <Navigation className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-black">نظام التتبع اللحظي للشحنات</h3>
              <p className="text-xs text-slate-300">راقب موقع بضاعتك وحالة الشاحنة دقيقة بدقيقة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-6">
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              رقم البوليصة أو كود التتبع:
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="مثال: CT-89214 أو CT-77410"
                  className="w-full pl-4 pr-10 py-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-hidden"
                />
                <Search className="absolute right-3.5 top-3.5 w-4 h-4 text-slate-400" />
              </div>
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors cursor-pointer shadow-sm"
              >
                تتبع الآن
              </button>
            </div>
            
            {/* Quick Suggestions */}
            <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
              <span>جرّب أرقام شحنات تجريبية:</span>
              <button 
                type="button" 
                onClick={() => { setSearchQuery('CT-89214'); setCurrentShipment(SAMPLE_SHIPMENTS[0]); }}
                className="text-blue-600 font-bold hover:underline cursor-pointer"
              >
                CT-89214
              </button>
              <span>•</span>
              <button 
                type="button" 
                onClick={() => { setSearchQuery('CT-77410'); setCurrentShipment(SAMPLE_SHIPMENTS[1]); }}
                className="text-blue-600 font-bold hover:underline cursor-pointer"
              >
                CT-77410
              </button>
            </div>
          </form>

          {notFound ? (
            <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-center text-red-700">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-red-500" />
              <p className="font-bold">لم يتم العثور على شحنة بهذا الرقم</p>
              <p className="text-xs text-red-600 mt-1">يرجى التأكد من كتابة الرقم بشكل صحيح</p>
            </div>
          ) : currentShipment && (
            <div className="space-y-6">
              
              {/* Shipment Details Card */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3 mb-3">
                  <div>
                    <span className="text-xs text-slate-500 block">رقم البوليصة:</span>
                    <span className="text-lg font-black text-blue-700 font-mono">{currentShipment.trackingNumber}</span>
                  </div>
                  <div className="text-left">
                    <span className="text-xs text-slate-500 block">الحالة الحالية:</span>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      على الطريق السريع
                    </span>
                  </div>
                </div>

                {/* Cities & Route */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">من مدينة:</span>
                    <span className="font-bold text-slate-800 text-sm">{currentShipment.fromCity}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">إلى مدينة:</span>
                    <span className="font-bold text-slate-800 text-sm">{currentShipment.toCity}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">نوع الشاحنة:</span>
                    <span className="font-bold text-slate-800 text-sm">{currentShipment.truckType}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">الوصول التقديري:</span>
                    <span className="font-bold text-amber-600 text-sm">{currentShipment.estimatedArrival}</span>
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                  <span>الموقع الحالي: {currentShipment.currentLocation}</span>
                  <span className="text-blue-600">{currentShipment.progressPercent}% تم إنجازه</span>
                </div>
                <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-l from-blue-600 to-sky-400 rounded-full transition-all duration-1000 relative"
                    style={{ width: `${currentShipment.progressPercent}%` }}
                  >
                    <div className="absolute left-0 top-0 bottom-0 w-2 bg-white/40 animate-pulse"></div>
                  </div>
                </div>
              </div>

              {/* Milestones Timeline */}
              <div className="grid grid-cols-4 gap-2 pt-2 text-center text-xs">
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-slate-800">تم الطلب</span>
                  <span className="text-[10px] text-slate-400">08:30 ص</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-slate-800">تم التحميل</span>
                  <span className="text-[10px] text-slate-400">11:15 ص</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center mb-1 ring-4 ring-blue-100">
                    <Truck className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-blue-600">في الطريق</span>
                  <span className="text-[10px] text-blue-500 font-semibold">مباشر الآن</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center mb-1">
                    <Clock className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-slate-500">التسليم</span>
                  <span className="text-[10px] text-slate-400">قريباً</span>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-100 cursor-pointer"
          >
            إغلاق النافذة
          </button>
        </div>

      </div>
    </div>
  );
};
