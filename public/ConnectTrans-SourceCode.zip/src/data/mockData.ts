import { Shipment, Testimonial, FaqItem } from '../types';

export const CITIES = [
  'الرياض', 'جدة', 'الدمام', 'مكة المكرمة', 'المدينة المنورة', 
  'القصيم', 'تبوك', 'أبها', 'حائل', 'الجبيل', 'ينبع', 'الهفوف',
  'القاهرة', 'الإسكندرية', 'السويس', 'دبي', 'أبوظبي'
];

export const TRUCK_TYPES = [
  { id: 'flatbed', name: 'تريلا سطحة (Flatbed)', capacity: '25-30 طن' },
  { id: 'curtain', name: 'تريلا جوانب ستارة (Curtainsider)', capacity: '25-30 طن' },
  { id: 'box', name: 'شاحنة صندوق مقفل (Box Truck)', capacity: '15-20 طن' },
  { id: 'reefer', name: 'تريلا مبردة (Reefer)', capacity: '22-26 طن' },
  { id: 'dyna', name: 'دينا نقل متوسط (Medium Dyna)', capacity: '4-7 طن' },
  { id: 'heavy', name: 'لوبد نقل ثقيل (Lowboy)', capacity: '40-60 طن' },
];

export const SAMPLE_SHIPMENTS: Shipment[] = [
  {
    id: '1',
    trackingNumber: 'CT-89214',
    sender: 'شركة الفنار للصناعات الكهربائية',
    fromCity: 'الرياض',
    toCity: 'جدة',
    truckType: 'تريلا صندوق مقفل',
    cargoType: 'معدات وأدوات كهربائية',
    weightTons: 22,
    price: 3400,
    status: 'in_transit',
    currentLocation: 'بالقرب من الطائف (طريق السيل)',
    progressPercent: 78,
    estimatedArrival: 'اليوم، 06:30 مساءً'
  },
  {
    id: '2',
    trackingNumber: 'CT-77410',
    sender: 'مؤسسة الرواد للمواد الغذائية',
    fromCity: 'الدمام',
    toCity: 'الرياض',
    truckType: 'تريلا مبردة (-18 مئوية)',
    cargoType: 'منتجات غذائية مجمدة',
    weightTons: 25,
    price: 2800,
    status: 'in_transit',
    currentLocation: 'محطة سعد (طريق الدمام السريع)',
    progressPercent: 45,
    estimatedArrival: 'اليوم، 09:15 مساءً'
  },
  {
    id: '3',
    trackingNumber: 'CT-66320',
    sender: 'مكتب الجزيرة للخدمات اللوجستية',
    fromCity: 'الجبيل',
    toCity: 'ينبع',
    truckType: 'تريلا سطحة',
    cargoType: 'أنابيب بتروكيماوية ومعادن',
    weightTons: 28,
    price: 5200,
    status: 'pending',
    currentLocation: 'منطقة التحميل بالجبيل الصناعية',
    progressPercent: 10,
    estimatedArrival: 'غداً، 11:00 صباحاً'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'م. خالد السبيعي',
    role: 'مدير العمليات اللوجستية',
    company: 'شركة الأفق لمواد البناء',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'منصة ConnectTrans غيرت تماماً طريقتنا في توفير الشاحنات. سابقاً كنا ننتظر ساعات للعثور على سيارات نقل موثوقة، والآن بضغطة زر تتوفر لدينا أحدث الشاحنات مع أسعار تنافسية وتتبع لحظي.',
    city: 'الرياض'
  },
  {
    id: '2',
    name: 'الكابتن أحمد عبدالرحمن',
    role: 'مالك وسائق شاحنة نقل ثقيل',
    company: 'أسطول شاحنات الفرسان',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'كنت أعاني من مشوار العودة الفارغ، لكن مع ConnectTrans أصبحت شاحنتي محملة ذهاباً وإياباً، وزاد دخلي الشهري بنسبة تزيد عن 40% دون أي تأخير في المستحقات المالية.',
    city: 'جدة'
  },
  {
    id: '3',
    name: 'أ/ سامي الهاشمي',
    role: 'مدير مكتب نقل وسيط',
    company: 'مكتب النخبة لخدمات الشحن البري',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'الربط السلس بين أصحاب السيارات والشركات عبر لوحة تحكم واحدة خفف عنا أعباء الاتصالات والوساطة التقليدية. ميزة التوثيق والأمان تمنح الجميع ثقة تامة.',
    city: 'الدمام'
  }
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    category: 'general',
    question: 'ما هي منصة ConnectTrans؟',
    answer: 'منصة رقمية موحدة ومتطورة لخدمات النقل واللوجستيات تربط بصورة مباشرة بين مكاتب النقل، أصحاب الشاحنات والسيارات، والشركات التجارية والصناعية لتوفير شحنات سريعة وموثوقة بأفضل الأسعار وبأعلى معايير الأمان.'
  },
  {
    category: 'trucks',
    question: 'كيف يستفيد أصحاب الشاحنات والسيارات من المنصة؟',
    answer: 'يحصل أصحاب وسائقو الشاحنات على شحنات فورية ومستمرة، مع القضاء على مشكلة الرحلات العائدة فارغة، وضمان سداد فوري للمستحقات، وإدارة جميع الوثائق وعقود النقل رقمياً.'
  },
  {
    category: 'payment',
    question: 'ما هي رسوم وعمولة المنصة خلال الفترة التجريبية؟',
    answer: 'الاشتراك والعمولة مجانية 100% خلال الفترة التجريبية لجميع المسجلين الجدد! يمكنك استخدام كافة أدوات الربط والبحث وإدارة الشحنات بدون أي رسوم خفية.'
  },
  {
    category: 'tracking',
    question: 'كيف يعمل نظام تتبع الشحنات اللحظي؟',
    answer: 'بمجرد قبول وتأكيد الرحلة، يحصل العميل والناقل على رمز تتبع مباشر (Tracking ID) يتيح مراقبة موقع الشاحنة وحالة الشحنة وسرعة النقل ووقت الوصول التقديري لحظة بلحظة عبر الخريطة التفاعلية.'
  },
  {
    category: 'general',
    question: 'ما هي الوثائق المطلوبة للتسجيل في ConnectTrans؟',
    answer: 'للشركات: السجل التجاري ورقم الضريبة. لأصحاب الشاحنات: رخصة القيادة العمومي، استمارة المركبة، وفحص السلامة. لمكاتب النقل: ترخيص النقل البري المعتمد.'
  }
];
