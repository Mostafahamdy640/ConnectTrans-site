import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { HowItWorksPage } from './pages/HowItWorksPage';
import { BusinessConnectionsPage } from './pages/BusinessConnectionsPage';
import { ReviewsPage } from './pages/ReviewsPage';
import { ContactPage } from './pages/ContactPage';
import { FaqPage } from './pages/FaqPage';
import { TrackingModal } from './components/TrackingModal';
import { AuthModal } from './components/AuthModal';
import { RoleDetailsModal } from './components/RoleDetailsModal';
import { ServiceDetailsModal } from './components/ServiceDetailsModal';
import { BookingModal } from './components/BookingModal';
import { PageId, UserRole } from './types';
import { CheckCircle2, Download } from 'lucide-react';
import { exportProjectToZip } from './utils/zipExporter';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  
  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [authInitialRole, setAuthInitialRole] = useState<UserRole>('company');

  const [trackingModalOpen, setTrackingModalOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [selectedServiceKey, setSelectedServiceKey] = useState<string | null>(null);
  
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<any>(null);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
    window.location.hash = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Sync hash routing
  useEffect(() => {
    const syncPageFromHash = () => {
      const hash = window.location.hash.replace('#', '') as PageId;
      const validPages: PageId[] = ['home', 'services', 'how-it-works', 'business', 'reviews', 'contact', 'faq'];
      if (validPages.includes(hash)) {
        setCurrentPage(hash);
      }
    };
    syncPageFromHash();
    window.addEventListener('hashchange', syncPageFromHash);
    return () => window.removeEventListener('hashchange', syncPageFromHash);
  }, []);

  const handleOpenAuth = (mode: 'login' | 'register', role: UserRole = 'company') => {
    setAuthMode(mode);
    setAuthInitialRole(role);
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = (userData: { name: string; role: UserRole }) => {
    showToast(`مرحباً بك ${userData.name}! تم تسجيل حسابك بنجاح في ConnectTrans.`);
  };

  const handleBookShipment = (details: any) => {
    setBookingDetails(details);
    setBookingModalOpen(true);
  };

  const handleServiceSelect = (serviceKey: string) => {
    if (serviceKey === 'tracking') {
      setTrackingModalOpen(true);
    } else {
      setSelectedServiceKey(serviceKey);
    }
  };

  const handleServiceAction = () => {
    if (selectedServiceKey === 'orders') {
      setBookingModalOpen(true);
    } else {
      handleOpenAuth('register');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fafafa] text-slate-900 selection:bg-blue-600 selection:text-white relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 left-1/2 transform -translate-x-1/2 z-50 bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-3 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Floating Download Source ZIP Action Badge */}
      <aside aria-label="تحميل المشروع" className="fixed bottom-5 left-5 z-40">
        <button
          onClick={() => exportProjectToZip()}
          title="تحميل كود المشروع كملف مضغوط ZIP"
          className="group flex items-center gap-2.5 px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl shadow-xl border border-slate-700 transition-all hover:scale-105 cursor-pointer"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Download className="w-4 h-4 group-hover:animate-bounce" />
          </div>
          <div className="text-right">
            <span className="block text-xs font-black text-white">تحميل المشروع كاملاً</span>
            <span className="block text-[10px] text-amber-400 font-mono">ZIP Source Code</span>
          </div>
        </button>
      </aside>

      {/* Navigation Bar with Page Switching */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenAuth={handleOpenAuth}
        onOpenTracking={() => setTrackingModalOpen(true)}
      />

      {/* Main Single Page Renderer */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onOpenAuth={handleOpenAuth}
            onOpenTracking={() => setTrackingModalOpen(true)}
            onSelectRole={(role) => setSelectedRole(role)}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            onNavigateHome={() => handleNavigate('home')}
            onSelectService={handleServiceSelect}
            onBookShipment={handleBookShipment}
            onOpenTracking={() => setTrackingModalOpen(true)}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {currentPage === 'how-it-works' && (
          <HowItWorksPage
            onNavigateHome={() => handleNavigate('home')}
            onRegisterRole={(role) => handleOpenAuth('register', role)}
            onOpenTracking={() => setTrackingModalOpen(true)}
          />
        )}

        {currentPage === 'business' && (
          <BusinessConnectionsPage
            onNavigateHome={() => handleNavigate('home')}
            onSelectRole={(role) => setSelectedRole(role)}
            onOpenAuth={handleOpenAuth}
            onBookShipment={handleBookShipment}
          />
        )}

        {currentPage === 'reviews' && (
          <ReviewsPage
            onNavigateHome={() => handleNavigate('home')}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            onNavigateHome={() => handleNavigate('home')}
            onOpenTracking={() => setTrackingModalOpen(true)}
          />
        )}

        {currentPage === 'faq' && (
          <FaqPage
            onNavigateHome={() => handleNavigate('home')}
            onNavigateContact={() => handleNavigate('contact')}
          />
        )}
      </main>

      {/* Footer with page links */}
      <Footer onNavigate={handleNavigate} />

      {/* Interactive Modals */}
      <TrackingModal
        isOpen={trackingModalOpen}
        onClose={() => setTrackingModalOpen(false)}
      />

      <AuthModal
        isOpen={authModalOpen}
        mode={authMode}
        initialRole={authInitialRole}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      <RoleDetailsModal
        role={selectedRole}
        onClose={() => setSelectedRole(null)}
        onProceedToRegister={(role) => handleOpenAuth('register', role)}
        onOpenTracking={() => setTrackingModalOpen(true)}
      />

      <ServiceDetailsModal
        serviceKey={selectedServiceKey}
        onClose={() => setSelectedServiceKey(null)}
        onAction={handleServiceAction}
      />

      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        initialDetails={bookingDetails}
      />

    </div>
  );
}
