export type UserRole = 'company' | 'driver' | 'office';

export type PageId = 'home' | 'services' | 'how-it-works' | 'business' | 'reviews' | 'contact' | 'faq';

export interface Shipment {
  id: string;
  trackingNumber: string;
  sender: string;
  fromCity: string;
  toCity: string;
  truckType: string;
  cargoType: string;
  weightTons: number;
  price: number;
  status: 'pending' | 'in_transit' | 'delivered' | 'cancelled';
  currentLocation: string;
  progressPercent: number;
  estimatedArrival: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  rating: number;
  comment: string;
  city: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: 'general' | 'payment' | 'tracking' | 'trucks';
}
